package com.inclusive.vulcain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
