# Vulcain

## Installation

Suivre les instructions :
`https://flutter.dev/docs/get-started/install`

## Lancement

Au premier lancement de l'application, le projet prendra plusieurs minutes pour charger les données en base.

## Déploiement

Une configuration firebase est nécessaire pour permettre à firebase auth de fonctionner.
Se référer à `https://pub.dev/packages/firebase_auth`.
